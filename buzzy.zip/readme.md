## Buzzy Media Script

Breaking News, Viral Lists, Awesome Polls and Popular Videos. 

Buzzy brings to all these contents into one system. Create beautiful viral websites like BuzzFeed with Buzzy! 
You have advanced tools to do that. Great Post Editor, 
Powerfull Admin Panel and Impressive Design will you think big!

Get Started to make great community with Buzzy. TODAY!

## Official Documentation

Documentation for the Buzzy can be found on the [Buzzy website](http://buzzy.akbilisim.com/admin/docs).

### License

The Buzzy is GNU General Public License [GNU license](http://www.gnu.org/licenses/gpl-3.0.en.html)

Copyright © 2015 akbilisim. All rights reserved. [Website](http://www.akbilisim.com/).