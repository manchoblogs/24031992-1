<?php

return [
    'approved' => 'Merhaba :UserName, Harika haberlerimiz var!<br>
                   <b>:PostTitle</b> başlıklı içeriğiniz yönetim onayından geçmiştir. Bu adresten içeriğinizi görebilir ve arkadaşlarınız ile paylaşabilirsiniz:<br> <b>:Postlink</b>',

    'approvedsubject' => 'Yazın onaylandı!',

    'trashed' => 'Merhaba :UserName, Kötü haberlerimiz var!<br>
                  <b>:PostTitle</b>  başlıklı yazınız yönetim tarafından kaldırıldı. :(',

    'trashsubject' => 'Yazın yayından kaldırıldı!',
];
