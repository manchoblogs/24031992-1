<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'Kayıtlarımızda böyle bir üyelik bulunamadı.',
    'throttle' => '',

    'congratz' => 'Tebrikler',
    'joined' => 'Aramıza katıldınığız yönlendiriyolorsunuz..',
    'logined' => 'Başarılı bir şekilde giriş yaptınız',

    'cantgetemail' => 'Mail adresinizi alamadık. Lütfen emailiniz ile yeni kayıt oluşturunuz',


];
