<?php

return array (
  'password' => 'la contraseña debe ser de al menos 6 caracteres.',
  'reset' => 'tu contraseña ha sido modificada!',
  'sent' => 'hemos enviado la modificación de contraseña a tu correo!',
  'token' => 'la modicifacion de la contraseña no fue exitosa.',
  'user' => 'no se encuentra un usuario con ese correo.',
  'passwordreslink' => 'enviar link de modificacion',
  'yourpasswordreslink' => 'tu link de la modificacion de la contraseña',
  'forgotpassword' => 'olvidaste tu contraseña? ',
  'resetpass' => 'modificar contraseña',
  'passemail' => 'Email',
  'passpassword' => 'contraseña',
  'passpasswordconf' => 'confirmas contraseña',
);
