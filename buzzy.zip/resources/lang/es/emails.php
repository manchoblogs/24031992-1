<?php

return [
    'approved' => 'hola :UserName, tenemos grandes noticias!<br>
                   tu post <b>:PostTitle</b> ha sido aprobado. compartelo con este url:<br> <b>:Postlink</b>',

    'approvedsubject' => 'tu post ha sido aprobado!',

    'trashed' => 'hola :UserName, tenemos malas noticias!<br>
                  tu post <b>:PostTitle</b> ha sido borrado. :(',

    'trashsubject' => 'tu post ha sido borrado!',
];