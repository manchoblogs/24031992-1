<?php

return array(

    'themes' => 'Шаблоны',


);
