<div class="modeempty-header">
    <div class="modeempty_text">

        <i class="material-icons" style="font-size:69px!important">&#xE001;</i>
        <h4>{{ trans('index.emptyplace') }}</h4>
    </div>

</div>