@extends("app")
@section('content')

    <div class="buzz-container">
        <div class="global-container container">


            <div class="content" style="float:none;margin:0 auto;width:500px;padding:150px 0 350px 0;text-align: center">
                <img src="{{ asset('/assets/img/404.png') }}">
                <div class="clear"></div>
                <a href="/"  style="margin-top:50px" class="button button-big button-orange">Go Back Home</a>
            </div>

        </div>
    </div>

@endsection
